// --- Eks ----

console.log("---Eksempel---")

function sjekkTall(tall){
    if(tall == 10){
        console.log("tallet er 10");
    }
    else if(tall > 5){
        console.log("tallet er ikke 10, og større enn 5");
    }
    else{
        console.log("tallet er ikke 10, og ikke større enn 5");
    }
}

sjekkTall(10);
sjekkTall(5);
sjekkTall(55);

// --- 3a ---
console.log("--- 3a ---")
/* 
Lag en funksjon som tar inn navn og alder. 
Hvis alder er under 30, skal funksjonen skrive ut "hei navn, du er ung!"
Hvis ikke alder er under 30 skal funksjonen skrive ut "du er gammel!"

Funksjonen skal testes med Lise, 78 og Janne, 28
*/

// Skriv koden din her

// --- Fasit ---
console.log("--- Fasit ---");
console.log('3a: "du er gammel!" og "hei Janne, du er ung!"');
